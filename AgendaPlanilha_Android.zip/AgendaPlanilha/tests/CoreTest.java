import br.com.agendaplanilha.*;
import java.util.*;
import java.io.*;
public class CoreTest {
 public static void main(String[] args)throws Exception {
  if(!Contact.normalize("(11) 99999-1234").equals("+5511999991234"))throw new AssertionError();
  if(!new Contact("", "1234").name.equals("Contato sem nome"))throw new AssertionError();
  if(!new Contact("+55 11 99999-1234", "11999991234").name.equals("Contato sem nome"))throw new AssertionError();
  if(!Contact.normalize("+44 1234567890").equals("+441234567890"))throw new AssertionError();
  Xlsx.write(new FileOutputStream(args[0]),Arrays.asList(new Contact("Ana & João <teste>","11999991234"),new Contact("=1+1","1234"),new Contact("","5511988881234")));
  System.out.println("PASS: normalization and missing names; XLSX generated");
 }
}
