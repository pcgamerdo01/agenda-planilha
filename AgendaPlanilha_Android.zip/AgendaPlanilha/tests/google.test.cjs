const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
let data=[],locked=false;
const sheet={getLastRow:()=>data.length,getRange(r,c,n,m){return {getDisplayValues:()=>data.slice(r-1,r-1+n).map(x=>x.map(v=>v.startsWith("'")?v.slice(1):v)),setValues(rows){rows.forEach((row,i)=>data[r-1+i]=row);return this},setNumberFormat(){return this},setFontWeight(){return this},setBackground(){return this}}},setFrozenRows(){},setColumnWidth(){}};
const ctx={ContentService:{MimeType:{JSON:'json'},createTextOutput:s=>({setMimeType:()=>JSON.parse(s)})},PropertiesService:{getScriptProperties:()=>({getProperty:k=>k==='TOKEN'?'x'.repeat(32):'sheet'})},LockService:{getScriptLock:()=>({waitLock(){locked=true},hasLock:()=>locked,releaseLock(){locked=false}})},SpreadsheetApp:{openById:()=>({getSheetByName:()=>sheet})}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('google/Code.gs','utf8'),ctx);
function send(contacts,token='x'.repeat(32)){return ctx.doPost({postData:{contents:JSON.stringify({token,contacts})}})}
assert.equal(send([{phone:'+5511999991234',name:'Ana'}],'wrong').ok,false);assert.equal(data.length,0);
assert.equal(send([{phone:'+5511999991234',name:'Ana'},{phone:'1234',name:''}]).ok,true);assert.equal(data.length,3);
assert.equal(send([{phone:'+5511999991234',name:'=MALICIOUS()'}]).ok,true);assert.equal(data.length,3);assert.equal(data[1][0],"'=MALICIOUS()");
assert.equal(data[2][0],'Contato sem nome');assert.equal(send([{phone:'abc',name:'Erro'}]).ok,false);assert.equal(locked,false);
console.log('PASS: authentication, upsert, missing name, formula escaping, invalid phone, lock release');
