# Gere o instalador pelo celular

Este pacote contém o projeto e a configuração de compilação. O APK só existirá após uma execução bem-sucedida no GitHub. Não é necessário instalar Android Studio no celular.

## 1. Criar o repositório
No Chrome, entre na sua conta em https://github.com/new. Se algum botão não aparecer, abra ⋮ → Versão para computador. Crie um repositório chamado `agenda-planilha`, habilite Add a README e escolha a visibilidade.

Para compilar sem cobrança de minutos, um repositório público com runner padrão é a opção gratuita. Isso torna o código público, não os contatos do aparelho. Envie somente este projeto: não envie agenda, planilhas, chave Google ou informações pessoais. Repositório privado usa as cotas do seu plano; não habilite gastos adicionais se deseja manter custo zero. Os instaladores desta configuração expiram após 3 dias para limitar armazenamento.

## 2. Enviar o ZIP, sem precisar subir pastas
No repositório: Add file → Upload files → Choose your files. Selecione **AgendaPlanilha_Android.zip** exatamente com esse nome, e finalize em Commit changes.
O arquivo deve aparecer junto ao README na raiz. Não é necessário extrair ou enviar todos os arquivos ao GitHub: o workflow fará a extração.
Se o Android renomeou para `AgendaPlanilha_Android (1).zip`, renomeie antes de enviar.

## 3. Criar o workflow
No gerenciador Arquivos do Android, extraia o ZIP localmente. Abra a pasta AgendaPlanilha e abra `WORKFLOW_COPIAR.txt` como texto. Selecione e copie todo o conteúdo.
No GitHub, escolha Add file → Create new file.
No campo de nome, escreva exatamente:

`.github/workflows/gerar-apk.yml`

Cole o conteúdo copiado no editor. Toque em Commit changes e salve na branch principal (normalmente main). Apenas enviar o ZIP não ativa o Actions: este arquivo precisa existir fora dele, nesse caminho.

## 4. Gerar o APK
Abra a aba Actions. Se aparecer uma tela para habilitar Actions, habilite para o seu repositório.
Selecione **Gerar APK Android** → **Run workflow** → selecione main → **Run workflow**.
Aguarde a execução terminar. Abra a execução para acompanhar as etapas. Verde indica sucesso; vermelho indica erro — abra a etapa vermelha e envie o erro para correção.

## 5. Baixar e instalar
Abra a execução verde e role até **Artifacts**. Toque em **AgendaPlanilha-APK** estando conectado à sua conta GitHub. O download é um ZIP: extraia para encontrar **AgendaPlanilha.apk**.
Toque no APK e, se solicitado, permita instalar aplicativos desta origem (Arquivos/Chrome). Não é necessário desativar o Play Protect. Conclua a instalação.
Abra Agenda Planilha → Ler / atualizar agenda → autorize Contatos → selecione os contatos → Salvar Excel.
Para enviar ao Google, siga a configuração única do LEIA-ME.md.

## Observações
- O PC pode permanecer desligado durante a compilação e durante o uso.
- Este é um APK de testes, não uma versão publicada na Play Store. A primeira compilação real ainda precisa ser validada no GitHub e o aplicativo no seu aparelho.
- Cada execução pode gerar uma assinatura de teste diferente. Para instalar uma nova compilação, talvez seja necessário desinstalar a anterior, perdendo a configuração local do app. Sua agenda e planilhas exportadas não são apagadas. Assinatura estável de distribuição fica para uma versão posterior.
- A importação é iniciada pelo botão; sincronização em segundo plano não foi adicionada.

Fontes: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts e https://docs.github.com/en/billing/concepts/product-billing/github-actions
