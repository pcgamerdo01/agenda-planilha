package br.com.agendaplanilha;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.widget.*;
import android.view.*;
import android.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.io.*;
import java.net.*;
import org.json.*;
public class MainActivity extends Activity {
 final ExecutorService io=Executors.newSingleThreadExecutor();
 final ArrayList<Contact> contacts=new ArrayList<>(), visible=new ArrayList<>();
 final Set<String> selected=new HashSet<>();
 ArrayList<Contact> pending=new ArrayList<>();
 ListView list; TextView status; EditText search; ArrayAdapter<Contact> adapter; boolean busy=false;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,16);root.setBackgroundColor(0xfff3f6fa);
  root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(24,24+insets.getSystemWindowInsetTop(),24,16+insets.getSystemWindowInsetBottom());return insets;});
  TextView title=new TextView(this);title.setText("Agenda Planilha");title.setTextSize(28);title.setTextColor(0xff123b50);root.addView(title);
  TextView sub=new TextView(this);sub.setText("Sua agenda organizada, sem mensalidade.\nOs contatos só são enviados ao tocar em Google Planilhas.");root.addView(sub);
  button(root,"1 • Ler / atualizar agenda",()->load());
  search=new EditText(this);search.setHint("Buscar nome ou número");root.addView(search);
  LinearLayout choices=new LinearLayout(this);choices.setOrientation(1);root.addView(choices);
  button(choices,"Selecionar exibidos",()->{for(Contact c:visible)selected.add(c.phone);refresh();});
  button(choices,"Limpar seleção",()->{selected.clear();refresh();});
  status=new TextView(this);root.addView(status);status.setText("Toque em Ler agenda para começar.");
  list=new ListView(this);list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_multiple_choice,visible);list.setAdapter(adapter);
  root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
  list.setOnItemClickListener((a,v,pos,id)->{String phone=visible.get(pos).phone;if(list.isItemChecked(pos))selected.add(phone);else selected.remove(phone);count();});
  search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int before,int count){refresh();}public void afterTextChanged(Editable e){}});
  button(root,"2 • Salvar Excel (.xlsx)",()->excel());
  button(root,"2 • Atualizar Google Planilhas",()->send());
  button(root,"Configurar Google Planilhas",()->settings());setContentView(root);
 }
 void button(LinearLayout root,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setAllCaps(false);root.addView(b);b.setOnClickListener(v->{if(!busy)action.run();});}
 void message(String s){status.setText(s);}
 void count(){message(contacts.size()+" números únicos • "+selected.size()+" selecionados");}
 void refresh(){String q=search.getText().toString().toLowerCase(Locale.ROOT);visible.clear();for(Contact c:contacts)if(c.toString().toLowerCase(Locale.ROOT).contains(q))visible.add(c);adapter.notifyDataSetChanged();list.clearChoices();for(int i=0;i<visible.size();i++)list.setItemChecked(i,selected.contains(visible.get(i).phone));count();}
 void load(){if(checkSelfPermission(android.Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.READ_CONTACTS},10);return;}busy=true;message("Lendo agenda…");io.execute(()->{try{
  Map<String,Contact> map=new TreeMap<>();
  try(Cursor c=getContentResolver().query(Phone.CONTENT_URI,new String[]{Phone.DISPLAY_NAME,Phone.NUMBER},null,null,null)){
   if(c==null)throw new IOException("Não foi possível acessar a agenda.");
   while(c.moveToNext()){Contact x=new Contact(c.getString(0),c.getString(1));if(x.phone.isEmpty())continue;Contact old=map.get(x.phone);if(old==null || old.name.equals("Contato sem nome"))map.put(x.phone,x);}
  }
  ArrayList<Contact> rows=new ArrayList<>(map.values());rows.sort(Comparator.comparing(x->x.name.toLowerCase(Locale.ROOT)));
  runOnUiThread(()->{contacts.clear();contacts.addAll(rows);selected.retainAll(map.keySet());busy=false;refresh();});
 }catch(Exception e){fail("Não foi possível ler a agenda. Verifique a permissão de contatos.");}});}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==10 && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED)load();else message("Autorize Contatos nas configurações do Android para importar.");}
 ArrayList<Contact> chosen(){ArrayList<Contact> rows=new ArrayList<>();for(Contact c:contacts)if(selected.contains(c.phone))rows.add(c);if(rows.isEmpty())message("Selecione pelo menos um contato.");return rows;}
 void excel(){pending=chosen();if(pending.isEmpty())return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");i.putExtra(Intent.EXTRA_TITLE,"Contatos.xlsx");startActivityForResult(i,20);}
 @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r!=20 || result!=RESULT_OK || data==null || data.getData()==null)return;
  if(pending.isEmpty()){message("A sessão foi recriada. Selecione os contatos e exporte novamente.");return;}
  ArrayList<Contact> rows=new ArrayList<>(pending);android.net.Uri uri=data.getData();busy=true;io.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();Xlsx.write(out,rows);runOnUiThread(()->{busy=false;message("Excel salvo • "+rows.size()+" contatos.");});}catch(Exception e){fail("Não foi possível salvar o Excel. Tente outro local.");}});
 }
 android.content.SharedPreferences prefs(){return getSharedPreferences("config",MODE_PRIVATE);}
 void settings(){LinearLayout box=new LinearLayout(this);box.setPadding(28,16,28,16);box.setOrientation(1);
  EditText url=new EditText(this);url.setHint("URL do Apps Script terminada em /exec");url.setText(prefs().getString("url",""));box.addView(url);
  EditText token=new EditText(this);token.setHint("Chave secreta (32 caracteres ou mais)");token.setInputType(129);token.setText(prefs().getString("token",""));box.addView(token);
  new AlertDialog.Builder(this).setTitle("Google Planilhas").setMessage("Siga o LEIA-ME do projeto para criar sua integração. A chave fica no armazenamento privado deste aplicativo.").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{String u=url.getText().toString().trim(),t=token.getText().toString().trim();if(!u.matches("https://script\\.google\\.com/macros/s/[A-Za-z0-9_-]+/exec") || t.length()<32){message("Confira a URL e use uma chave com pelo menos 32 caracteres.");return;}prefs().edit().putString("url",u).putString("token",t).apply();message("Configuração salva.");}).show();
 }
 void send(){ArrayList<Contact> rows=chosen();if(rows.isEmpty())return;String u=prefs().getString("url",""),t=prefs().getString("token","");if(u.isEmpty() || t.isEmpty()){settings();return;}
  new AlertDialog.Builder(this).setTitle("Atualizar sua planilha?").setMessage("Enviar "+rows.size()+" contatos selecionados? Contatos existentes serão atualizados pelo número. Nenhum contato será apagado.").setNegativeButton("Cancelar",null).setPositiveButton("Enviar",(d,w)->{busy=true;message("Atualizando planilha…");io.execute(()->{try{
   JSONObject body=new JSONObject();body.put("token",t);JSONArray a=new JSONArray();for(Contact c:rows){JSONObject x=new JSONObject();x.put("name",c.name);x.put("phone",c.phone);a.put(x);}body.put("contacts",a);
   byte[] bytes=body.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
   HttpURLConnection conn=(HttpURLConnection)new URL(u).openConnection();conn.setConnectTimeout(20000);conn.setReadTimeout(30000);conn.setInstanceFollowRedirects(false);conn.setRequestMethod("POST");conn.setDoOutput(true);conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
   try{try(OutputStream out=conn.getOutputStream()){out.write(bytes);}int code=conn.getResponseCode();
    if(code==302 || code==303){String location=conn.getHeaderField("Location");URL redirect=new URL(location);if(!redirect.getProtocol().equals("https") || !redirect.getHost().equals("script.googleusercontent.com"))throw new IOException();conn.disconnect();conn=(HttpURLConnection)redirect.openConnection();conn.setConnectTimeout(20000);conn.setReadTimeout(30000);conn.setInstanceFollowRedirects(false);}
    if(conn.getResponseCode()!=200)throw new IOException();StringBuilder response=new StringBuilder();try(BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),java.nio.charset.StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null){response.append(line);if(response.length()>100000)throw new IOException();}}
    JSONObject result=new JSONObject(response.toString());if(!result.optBoolean("ok"))throw new IOException();runOnUiThread(()->{busy=false;message("Planilha atualizada • "+rows.size()+" contatos enviados.");});
   }finally{conn.disconnect();}
  }catch(Exception e){fail("Envio não confirmado. Confira internet, URL, chave e implantação. Repetir não duplica números.");}});}).show();
 }
 void fail(String m){runOnUiThread(()->{busy=false;message(m);});}
 @Override protected void onDestroy(){io.shutdown();super.onDestroy();}
}
