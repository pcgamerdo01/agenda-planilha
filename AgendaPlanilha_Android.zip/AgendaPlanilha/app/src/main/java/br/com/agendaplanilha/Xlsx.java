package br.com.agendaplanilha;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import java.nio.charset.StandardCharsets;
public class Xlsx {
 static String xml(String s) { return s.replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]", "").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
 static void entry(ZipOutputStream z,String name,String data)throws IOException { z.putNextEntry(new ZipEntry(name));z.write(data.getBytes(StandardCharsets.UTF_8));z.closeEntry(); }
 public static void write(OutputStream out,List<Contact> contacts)throws IOException {
  try(ZipOutputStream z=new ZipOutputStream(out)) {
   entry(z,"[Content_Types].xml","<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
   entry(z,"_rels/.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
   entry(z,"xl/workbook.xml","<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Contatos\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
   entry(z,"xl/_rels/workbook.xml.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
   StringBuilder s=new StringBuilder("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols><col min=\"1\" max=\"1\" width=\"36\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"24\" customWidth=\"1\"/></cols><sheetData>");
   s.append(row(1,"Nome","Telefone"));int i=2;
   for(Contact c:contacts)s.append(row(i++,c.name,c.phone));
   s.append("</sheetData><autoFilter ref=\"A1:B").append(i-1).append("\"/></worksheet>");
   entry(z,"xl/worksheets/sheet1.xml",s.toString());
  }
 }
 static String row(int i,String a,String b) { return "<row r=\""+i+"\"><c r=\"A"+i+"\" t=\"inlineStr\"><is><t xml:space=\"preserve\">"+xml(a)+"</t></is></c><c r=\"B"+i+"\" t=\"inlineStr\"><is><t xml:space=\"preserve\">"+xml(b)+"</t></is></c></row>"; }
}
