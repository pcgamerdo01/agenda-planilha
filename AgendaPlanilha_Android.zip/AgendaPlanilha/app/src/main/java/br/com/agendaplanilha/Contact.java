package br.com.agendaplanilha;
public class Contact {
 public final String name, phone;
 public Contact(String n, String p) { phone=normalize(p); name=n==null || n.trim().isEmpty() || normalize(n).equals(phone) ? "Contato sem nome" : n.trim(); }
 public static String normalize(String raw) {
  if(raw==null) return "";
  String s=raw.trim(), d=s.replaceAll("[^0-9]", "");
  if(d.isEmpty()) return "";
  if(s.startsWith("+")) return "+"+d;
  if((d.length()==12 || d.length()==13) && d.startsWith("55")) return "+"+d;
  if(d.length()==10 || d.length()==11) return "+55"+d;
  return d;
 }
 public String toString() { return name+"\n"+phone; }
}
