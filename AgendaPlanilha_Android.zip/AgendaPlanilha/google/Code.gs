function doPost(e) {
  const reply = obj => ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
  const lock = LockService.getScriptLock();
  try {
    const props = PropertiesService.getScriptProperties();
    const secret = props.getProperty('TOKEN');
    if (!e || !e.postData || e.postData.contents.length > 2000000) return reply({ok:false});
    const body = JSON.parse(e.postData.contents);
    if (!secret || secret.length < 32 || body.token !== secret) return reply({ok:false});
    if (!Array.isArray(body.contacts) || !body.contacts.length || body.contacts.length > 10000) return reply({ok:false});
    const incoming = new Map();
    for (const row of body.contacts) {
      if (typeof row.phone !== 'string' || !/^\+?[0-9]{1,20}$/.test(row.phone)) return reply({ok:false});
      const name = typeof row.name === 'string' && row.name.trim() ? row.name.trim().slice(0,500) : 'Contato sem nome';
      incoming.set(row.phone, name);
    }
    lock.waitLock(20000);
    const book = SpreadsheetApp.openById(props.getProperty('SPREADSHEET_ID'));
    const sheet = book.getSheetByName('Agenda_Importada') || book.insertSheet('Agenda_Importada');
    // This tab is owned by the integration. Other tabs and columns are untouched.
    const existing = sheet.getLastRow() > 1 ? sheet.getRange(2,1,sheet.getLastRow()-1,2).getDisplayValues() : [];
    const index = new Map(existing.map((row,i)=>[row[1],i+2]));
    sheet.getRange(1,1,1,2).setValues([['Nome','Telefone']]).setFontWeight('bold').setBackground('#dbeaf3');
    const text = value => /^[=+\-@']/.test(value) ? "'"+value : value;
    const append = [];
    for (const [phone,name] of incoming) {
      const row = [text(name),text(phone)];
      if (index.has(phone)) sheet.getRange(index.get(phone),1,1,2).setNumberFormat('@').setValues([row]);
      else append.push(row);
    }
    if (append.length) sheet.getRange(Math.max(2,sheet.getLastRow()+1),1,append.length,2).setNumberFormat('@').setValues(append);
    sheet.setFrozenRows(1);sheet.setColumnWidth(1,280);sheet.setColumnWidth(2,190);
    return reply({ok:true,count:incoming.size});
  } catch(err) { return reply({ok:false}); }
  finally { if(lock.hasLock())lock.releaseLock(); }
}
