# Agenda Planilha — versão inicial Android

Projeto gratuito e sem anúncios para Android 8 ou superior. Não acessa o WhatsApp.

## O que foi implementado
- Leitura da agenda mediante permissão, sem modificar contatos do celular.
- Busca, seleção individual, seleção dos resultados exibidos e limpeza da seleção.
- Uma linha por telefone; duplicados normalizados são unidos, preferindo um nome preenchido.
- Nome vazio ou igual ao telefone vira **Contato sem nome**.
- Exportação local para Excel verdadeiro (.xlsx), com cabeçalho fixo, filtro e números como texto.
- Envio dos selecionados para Google Planilhas via integração na sua própria conta.
- Uso no celular com o PC desligado. Excel exportado e Google Planilhas podem ser abertos no PC; não há aplicativo Windows nesta versão.

## Limites desta entrega
Código-fonte inicial, não um APK pronto. Não foi compilado ou executado no Android neste ambiente, que não tem SDK Android/Gradle. A integração Google também precisa de configuração e teste real na sua conta. A importação e organização são automáticas após tocar no botão; ainda não há sincronização periódica em segundo plano. O Excel é uma exportação, não um arquivo mantido sincronizado.

## Gerar pelo celular

Siga **COMECE_PELO_CELULAR.md**. O pacote agora inclui o workflow do GitHub Actions e uma cópia em texto para colar pelo navegador. Não é necessário extrair o projeto no repositório: o workflow aceita este ZIP na raiz.

## Gerar o APK no Windows
1. Instale Android Studio e Android SDK 35 / Build Tools 35.0.0. Use JDK 17 e Gradle 8.11.1.
2. Extraia este ZIP. Instale a distribuição oficial Gradle 8.11.1 e adicione sua pasta `bin` ao PATH.
3. No terminal, dentro de AgendaPlanilha, execute `gradle wrapper --gradle-version 8.11.1` (gera o wrapper; não foi incluído um JAR não verificado).
4. Abra a pasta AgendaPlanilha no Android Studio, configure o SDK se solicitado e aguarde a sincronização.
5. Execute `gradlew.bat assembleDebug`. O arquivo estará em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK ao Android e autorize a instalação por essa origem. Para uso próprio não é necessário publicar na Play Store.
7. Abra o aplicativo, toque em Ler agenda e permita acesso aos contatos. Selecione os desejados e escolha o destino.
Após instalar, não é necessário deixar o PC ligado. A compilação inicial exige internet para baixar ferramentas.

## Google Planilhas: configuração única
1. Crie uma planilha e copie o ID entre `/d/` e `/edit` na URL.
2. Acesse https://script.google.com e crie um projeto. Cole `google/Code.gs`.
3. Em Configurações do projeto → Propriedades do script, crie `SPREADSHEET_ID` com o ID e `TOKEN` com uma chave aleatória longa, de pelo menos 32 caracteres. Use um gerenciador de senhas para gerar a chave. Não reutilize sua senha Google.
4. Implante como Aplicativo da Web, executando como você e com acesso Qualquer pessoa. Autorize o script na sua própria conta. O endpoint aceita requisições públicas, mas só grava com sua chave; não há função de leitura pública. Não publique a chave nem compartilhe o projeto.
5. Copie a URL terminada em `/exec`. No aplicativo, abra Configurar Google Planilhas e informe URL e chave.
6. Selecione os contatos e toque em Atualizar Google Planilhas. Confirme o envio.
A aba `Agenda_Importada` é reservada para a integração: colunas A e B são atualizadas pelo telefone. Outras abas não são alteradas. Contatos excluídos da agenda não são apagados da planilha. Um telefone alterado é tratado como um novo registro. Não edite manualmente telefones nessa aba. Repetir o envio atualiza os mesmos números. Caso um envio falhe após gravar parcialmente, repeti-lo completa a operação.
Se alterar o código do script, atualize a implantação com uma nova versão. Contas administradas podem bloquear implantação pública. Apps Script tem cotas; o projeto não exige API paga, mas não promete uso ilimitado.

## Normalização e privacidade
Números brasileiros com DDD (10 ou 11 dígitos) recebem +55. Números com + explícito são preservados. Números curtos ficam como estão: não inventamos DDD, nono dígito ou código de operadora. Esta primeira versão presume Brasil para números sem código internacional; revise números estrangeiros sem +. Ramais não têm campo próprio nesta versão. Contatos sem telefone não são exportados. A seleção é temporária e precisa ser refeita se o processo for encerrado. A chave Google fica no armazenamento privado do aplicativo, com backup Android desativado. Não há telemetria, anúncios ou servidor do desenvolvedor.

## Verificação antes de uso real
Teste primeiro com poucos contatos: sem nome, duplicados, dois números para uma pessoa, telefone internacional e nome começando com `=`. Confira Excel no celular e PC. No Google, envie duas vezes e confirme que não duplicou; altere um nome e repita. Verifique permissão negada, cancelamento ao salvar e envio sem rede.

## Fontes técnicas
- https://developer.android.com/guide/topics/providers/contacts-provider
- https://developer.android.com/training/data-storage/shared/documents-files
- https://developers.google.com/apps-script/guides/web
- https://developers.google.com/apps-script/guides/content
- https://developer.android.com/build/releases/agp-8-10-0-release-notes

## Testes executados nesta entrega
O núcleo Java (normalização e geração XLSX) foi compilado com Java 17 e testado. O XLSX gerado foi reaberto com openpyxl, verificando textos, acentos, números, cabeçalho e nome iniciado por sinal de fórmula. Testes isolados do Apps Script passaram para autenticação, atualização sem duplicação, nome ausente, escape de fórmulas e rejeição de número inválido. Não substituem testes Android e Google reais.
